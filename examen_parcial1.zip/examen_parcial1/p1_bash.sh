#!/bin/bash

#python3 p1_bash.py encoder radio numPulsos tiempo
python3 p1_bash.py 100 4 450 5



#Cómo ejecutar programa bash:

# chmod +x p1_bash.sh
# ./p1_bash.sh

